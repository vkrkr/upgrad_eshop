import { createBrowserRouter, RouterProvider } from "react-router-dom";

import Layout from "./components/layout/Layout";
import Login from "./components/login/Login";
import Signup from "./components/signup/Signup";
import Products from "./components/products/Products";
import AddProduct from "./components/add-product/AddProduct";
import ProductDetails from "./components/product-details/ProductDetails";
import PlaceOrder from "./components/place-order/PlaceOrder";
import { SnackbarProvider } from "./context/snackbarContext";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Products />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/signup",
    element: <Signup />,
  },
  {
    path: "/products",
    element: <Products />,
  },
  {
    path: "/add-product",
    element: <AddProduct />,
  },
  {
    path: "/modify-product/:id",
    element: <AddProduct />,
  },
  {
    path: "/product-details/:id",
    element: <ProductDetails />,
  },
  {
    path: "/place-order/:id",
    element: <PlaceOrder />,
  },
]);

export default function App() {
  return (
    <SnackbarProvider>
      <Layout>
        <RouterProvider router={router} />
      </Layout>
    </SnackbarProvider>
  );
}

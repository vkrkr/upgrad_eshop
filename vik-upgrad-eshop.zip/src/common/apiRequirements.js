export const hostname = "http://localhost:8080";

export const apiUrl = (api) => {
  return hostname + api;
};

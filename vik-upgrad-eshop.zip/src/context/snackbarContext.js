import { createContext, useContext, useState } from "react";

const SnackbarContext = createContext();

export const SnackbarProvider = ({ children }) => {
  const [open, setOpen] = useState(false);

  return (
    <SnackbarContext.Provider value={{ open, setOpen }}>
      {children}
    </SnackbarContext.Provider>
  );
};

export const useSnackbarContext = () => {
  const context = useContext(SnackbarContext);

  const handleClose = (reason) => {
    if (reason === "clickaway") {
      return;
    }

    context.setOpen(false);
  };

  if (!context) {
    throw new Error(
      "useSnackbarContext must be used within an SnackbarProvider"
    );
  }
  return { ...context, handleClose };
};

import { useCallback, useEffect, useState } from "react";
import axios from "axios";

import useLocalStorage from "./useLocalStorage";

export default function useGet(api) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState();
  const [data, setData] = useState();

  const { getToken } = useLocalStorage();

  const token = getToken();

  const getApi = useCallback(async () => {
    try {
      const response = await axios.get(api, {
        headers: {
          "x-auth-token": token,
        },
      });

      return response;
    } catch (error) {
      return error;
    }
  }, [api, token]);

  useEffect(() => {
    setLoading(true);
    getApi()
      .then((response) => {
        setData(response);
        setLoading(false);
      })
      .catch((error) => {
        setError(error);
        setData(undefined);
        setLoading(false);
      });
  }, [getApi]);

  return { loading, error, data };
}

import axios from "axios";
import useLocalStorage from "./useLocalStorage";

export default function useDelete() {
  const { getToken } = useLocalStorage();

  const token = getToken();

  const config = {
    headers: {
      "x-auth-token": token,
    },
  };

  const deleteApi = async (api) => {
    try {
      const response = await axios.delete(api, config);
      return response;
    } catch (error) {
      return error;
    }
  };

  return { deleteApi };
}

import axios from "axios";
import useLocalStorage from "./useLocalStorage";

export default function usePut() {
  const { getToken } = useLocalStorage();

  const token = getToken();

  const config = {
    headers: {
      "x-auth-token": token,
    },
  };

  const putApi = async (api, data) => {
    try {
      const response = await axios.put(api, data, config);
      return response;
    } catch (error) {
      return error;
    }
  };

  return { putApi };
}

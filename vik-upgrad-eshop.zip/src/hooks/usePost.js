import axios from "axios";
import useLocalStorage from "./useLocalStorage";

export default function usePost() {
  const { getToken } = useLocalStorage();

  const token = getToken();

  const config = {
    headers: {
      "x-auth-token": token,
    },
  };

  const postApi = async (api, data) => {
    try {
      const response = await axios.post(api, data, config);
      return response;
    } catch (error) {
      return error;
    }
  };

  return { postApi };
}

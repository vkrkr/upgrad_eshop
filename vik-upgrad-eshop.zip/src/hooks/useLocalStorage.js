export default function useLocalStorage() {
  const localKeyPrefix = "__upgrad_eshop__.";

  const setLocalData = (key, value) => {
    localStorage.setItem(localKeyPrefix + key, JSON.stringify(value));
  };

  const getToken = () => {
    return JSON.parse(localStorage.getItem(localKeyPrefix + "xAuthToken"));
  };

  const getRole = () => {
    return JSON.parse(localStorage.getItem(localKeyPrefix + "userRole"));
  };

  return { setLocalData, getToken, getRole };
}

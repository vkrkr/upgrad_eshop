import { Card, CardContent, Grid2, Stack, Typography } from "@mui/material";
import { useMemo } from "react";
import { useParams, useSearchParams } from "react-router-dom";

import products from "../products/products.json";

export default function FinalizeOrder({ address }) {
  const { id } = useParams();
  const [searchParams] = useSearchParams();

  const quantity = searchParams.get("quantity");

  const product = useMemo(
    () => products.find((product) => product.id === id),
    [id]
  );

  return (
    <Stack paddingX={15} paddingY={5} alignItems="center" minHeight={500}>
      <Card sx={{ width: "100%", flexGrow: 1 }}>
        <CardContent>
          <Grid2 container spacing={2}>
            <Grid2 size={7}>
              <Stack spacing={2}>
                <Typography variant="h4">{product.name}</Typography>
                <Typography variant="h6">
                  Quantity: <b>{quantity}</b>
                </Typography>
                <Typography variant="h6">
                  Category: <b>{product.category}</b>
                </Typography>
                <Typography variant="subtitle1">
                  <i>{product.description}</i>
                </Typography>
                <Typography variant="h5" color="red">
                  Total Price: &#8377; {product.price}
                </Typography>
              </Stack>
            </Grid2>
            <Grid2 size={5}>
              <Stack spacing={1}>
                <Typography variant="h4">Address Details: </Typography>
                <Stack>
                  <Typography variant="h6">{address.name}</Typography>
                  <Typography variant="h6">{address.street}</Typography>
                  <Typography variant="h6">
                    Contact Number: {address.contactNumber}
                  </Typography>
                  <Typography variant="h6">
                    {address.landmark}, {address.city}
                  </Typography>
                  <Typography variant="h6">{address.state}</Typography>
                  <Typography variant="h6">{address.zipcode}</Typography>
                </Stack>
              </Stack>
            </Grid2>
          </Grid2>
        </CardContent>
      </Card>
    </Stack>
  );
}

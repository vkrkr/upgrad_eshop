import { Grid2, Stack } from "@mui/material";
import Navbar from "../navbar/Navbar";

export default function Layout({ children }) {
  return (
    <Grid2 container direction="column">
      <Navbar />
      <Stack paddingX={10} paddingY={5}>
      {children}
      </Stack>
    </Grid2>
  );
}

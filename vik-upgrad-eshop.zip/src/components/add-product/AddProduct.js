import {
  Button,
  Card,
  CardActions,
  CardContent,
  Stack,
  Typography,
} from "@mui/material";
import { zodResolver } from "@hookform/resolvers/zod";
import { FormProvider, useForm } from "react-hook-form";
import { useParams } from "react-router-dom";
import { useState } from "react";
import z from "zod";

import products from "../products/products.json";
import FormInput from "../form-input/FormInput";
import FormInputNumber from "../form-input/FormInputNumber";
import CustomSnackbar from "../custom-snackbar/CustomSnackbar";
import useLocalStorage from "../../hooks/useLocalStorage";
import { apiUrl } from "../../common/apiRequirements";
import useGet from "../../hooks/useGet";
import usePost from "../../hooks/usePost";
import usePut from "../../hooks/usePut";

const formSchema = z.object({
  name: z.string().min(1, { message: "Name is mendatory" }),
  category: z.string().min(1, { message: "Category is mendatory" }),
  manufacturer: z.string().min(1, { message: "Manufacturer is mendatory" }),
  availableItems: z
    .string()
    .trim()
    .transform((value) => {
      return value === "" ? undefined : Number(value);
    })
    .refine(
      (val) => val !== undefined && Number.isInteger(val) && val > 0, // Ensure it's a positive integer
      { message: "Price is mandatory" }
    ),
  price: z
    .string()
    .trim()
    .transform((value) => {
      return value === "" ? undefined : Number(value);
    })
    .refine(
      (val) => val !== undefined && Number.isInteger(val) && val > 0, // Ensure it's a positive integer
      { message: "Price is mandatory" }
    ),
  imageUrl: z.string().optional(),
  productDescription: z.string().optional(),
});

export default function AddProduct() {
  const [isCreated, setIsCreated] = useState(false);
  const [isUpdated, setIsUpdated] = useState(false);
  const [open, setOpen] = useState(false);

  const { getToken, getRole } = useLocalStorage();
  const isAuthorized = Boolean(getToken()) && getRole.includes("ADMIN");

  const { id: productId } = useParams();

  const { data } = useGet(apiUrl(`/api/products/${productId}`));

  const { postApi } = usePost();
  const { putApi } = usePut();

  const product =
    data?.data ?? products.find((product) => product.id === productId);

  const form = useForm({
    defaultValues: {
      name: product && product.name ? product.name : "",
      category: product && product.category ? product.category : "",
      manufacturer: product && product.manufacturer ? product.manufacturer : "",
      availableItems:
        product && product.availableItems ? String(product.availableItems) : "",
      price: product && product.price ? String(product.price) : "",
      imageUrl: product && product.imageUrl ? product.imageUrl : "",
      productDescription:
        product && product.description ? product.description : "",
    },
    resolver: zodResolver(formSchema),
  });

  const onSubmit = async (data) => {
    if (product) {
      try {
        const response = await putApi(apiUrl(`/api/products/${productId}`), {
          ...data,
          id: productId,
        });
        if (response.status === 200) {
          setIsUpdated(true);
        }
      } catch (error) {
        console.log(error);
        setIsUpdated(false);
      }
    } else {
      try {
        const response = await postApi(apiUrl("/api/products"), {
          ...data,
          id: productId,
        });
        if (response.status === 200) {
          setIsCreated(true);
        }
      } catch (error) {
        console.log(error);
        setIsCreated(false);
      }
    }

    setOpen(true);
  };

  if (!isAuthorized) {
    return null;
  }

  return (
    <Stack width="100%" maxWidth={600} alignSelf="center">
      <Card>
        <CardContent>
          <Stack spacing={2}>
            <Typography variant="h5" textAlign="center">
              {product ? "Modify Product" : "Add Product"}
            </Typography>
            <FormProvider {...form}>
              <form id="add" onSubmit={form.handleSubmit(onSubmit)}>
                <Stack spacing={2}>
                  <FormInput form={form} name="name" label="Name *" />
                  <FormInput form={form} name="category" label="Category *" />
                  <FormInput
                    form={form}
                    name="manufacturer"
                    label="Manufacturer *"
                  />
                  <FormInputNumber
                    form={form}
                    name="availableItems"
                    label="Available Items *"
                  />
                  <FormInputNumber form={form} name="price" label="Price *" />
                  <FormInput form={form} name="imageUrl" label="Image URL" />
                  <FormInput
                    form={form}
                    name="productDescription"
                    label="Product Description"
                  />
                </Stack>
              </form>
            </FormProvider>
          </Stack>
        </CardContent>
        <CardActions sx={{ padding: 2 }}>
          <Button type="submit" form="add" variant="contained" fullWidth>
            {product ? "Modify Product" : "Add Product"}
          </Button>
        </CardActions>
      </Card>

      <CustomSnackbar
        open={open}
        handleClose={() => setOpen(false)}
        message={
          isCreated
            ? "Product Created Successfully."
            : isUpdated
            ? "Product Modified Successfully."
            : "Product Create/Update Failed."
        }
        severity={!isCreated && !isUpdated ? "error" : "success"}
      />
    </Stack>
  );
}

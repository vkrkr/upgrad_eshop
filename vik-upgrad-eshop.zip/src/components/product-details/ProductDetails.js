import {
  Box,
  Button,
  Chip,
  Grid2,
  Skeleton,
  Stack,
  Typography,
  useTheme,
} from "@mui/material";
import { FormProvider, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useParams } from "react-router-dom";
import z from "zod";

import { router } from "../../App";
import { apiUrl } from "../../common/apiRequirements";
import FormInputNumber from "../form-input/FormInputNumber";
import useGet from "../../hooks/useGet";
import Error from "../error/Error";
import products from "../products/products.json";

const formSchema = z.object({
  quantity: z.string().min(1, { message: "Quantity must be minimum 1" }),
});

export default function ProductDetails() {
  const theme = useTheme();

  const { id } = useParams();

  const { error, data } = useGet(apiUrl(`/api/products/${id}`));

  const form = useForm({
    defaultValues: {
      quantity: "",
    },
    resolver: zodResolver(formSchema),
  });

  const onSubmit = () => {
    router.navigate(
      `/place-order/${id}?quantity=${form.getValues("quantity")}`
    );
  };

  if (!data) {
    return <Skeleton variant="rectangular" width="100%" height={300} />;
  }

  if (!data && error) {
    return <Error />;
  }

  const product = data?.data ?? products.find((product) => product.id === id);

  return (
    <Grid2 container spacing={5}>
      <Grid2 size={5}>
        <Box
          sx={{
            maxWidth: "100%",
            height: 400,
            bgcolor: "grey",
            background: `url(${product.imageUrl})`,
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover",
          }}
        />
      </Grid2>
      <Grid2 size={7}>
        <Stack spacing={2}>
          <Stack direction="row" spacing={2} alignItems="center">
            <Typography variant="h4">{product.name}</Typography>
            <Chip
              label={`Available Quantity: ${product.availableItems ?? 0}`}
              size="small"
              sx={{
                bgcolor: theme.palette.primary.dark,
                color: theme.palette.grey[100],
              }}
            />
          </Stack>
          <Stack direction="row" spacing={1}>
            <Typography variant="body1">Category:</Typography>
            <Typography variant="body1" fontWeight={600}>
              {product.category}
            </Typography>
          </Stack>
          <Stack width="100%">
            <Typography variant="subtitle1">
              <i>{product.description}</i>
            </Typography>
          </Stack>
          <Typography variant="h5">&#8377; {product.price}</Typography>
          <FormProvider {...form}>
            <form id="quantity" onSubmit={form.handleSubmit(onSubmit)}>
              <Grid2 size={4}>
                <FormInputNumber
                  form={form}
                  name="quantity"
                  label="Enter Quantity *"
                />
              </Grid2>
            </form>
          </FormProvider>
          <Button
            type="submit"
            form="quantity"
            variant="contained"
            sx={{ width: "fit-content" }}
          >
            Place Order
          </Button>
        </Stack>
      </Grid2>
    </Grid2>
  );
}

import { FormControl, TextField } from "@mui/material";
import { Controller } from "react-hook-form";

export default function FormInputNumber({ form, name, label }) {
  const handleKeyDown = (e) => {
    if (
      !/^\d$/.test(e.key) &&
      !["Backspace", "Delete", "ArrowLeft", "ArrowRight"].includes(e.key)
    ) {
      e.preventDefault();
    }
  };

  return (
    <FormControl fullWidth>
      <Controller
        name={name}
        control={form.control}
        render={({ field, fieldState }) => (
          <TextField
            label={label}
            variant="outlined"
            error={!!fieldState.error}
            helperText={fieldState.error?.message}
            slotProps={{
              input: {
                inputMode: "numeric",
                pattern: "[0-9]*",
              },
            }}
            onKeyDown={handleKeyDown}
            onChange={(e) => {
              const value = e.target.value.replace(/[^0-9]/g, "");
              field.onChange(value);
            }}
            {...field}
          />
        )}
      />
    </FormControl>
  );
}

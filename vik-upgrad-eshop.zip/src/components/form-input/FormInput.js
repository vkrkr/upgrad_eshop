import { FormControl, TextField } from "@mui/material";
import { Controller } from "react-hook-form";

export default function FormInput({ form, name, label }) {
  return (
    <FormControl fullWidth>
      <Controller
        name={name}
        control={form.control}
        render={({ field, fieldState }) => (
          <TextField
            label={label}
            variant="outlined"
            error={!!fieldState.error}
            helperText={fieldState.error?.message}
            {...field}
          />
        )}
      />
    </FormControl>
  );
}

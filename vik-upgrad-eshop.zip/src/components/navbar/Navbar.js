import {
  AppBar,
  Box,
  Button,
  Grid2,
  Stack,
  Toolbar,
  Typography,
  useTheme,
} from "@mui/material";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";

import { router } from "../../App";
import Search from "../search/Search";
import useLocalStorage from "../../hooks/useLocalStorage";

export default function Navbar() {
  const theme = useTheme();

  const { getToken, getRole } = useLocalStorage();
  const isAuthorized = Boolean(getToken()) && getRole.includes("ADMIN");

  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar>
          <Grid2 container width="100%">
            <Grid2 size={4}>
              <Stack direction="row" alignItems="center" spacing={1}>
                <ShoppingCartIcon />
                <Typography variant="h6" fontWeight={600} noWrap>
                  upGrad E-Shop
                </Typography>
              </Stack>
            </Grid2>
            <Grid2 size={4}>
              <Search />
            </Grid2>
            <Grid2 size={4}>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="flex-end"
                maxHeight={40}
                spacing={1}
              >
                <Button
                  variant="text"
                  color={theme.palette.grey[100]}
                  onClick={() => router.navigate("/products")}
                >
                  Home
                </Button>
                {isAuthorized && (
                  <Button
                    variant="text"
                    color={theme.palette.grey[100]}
                    onClick={() => router.navigate("/add-product")}
                  >
                    Add Product
                  </Button>
                )}
                <Button
                  variant="contained"
                  sx={{
                    bgcolor: theme.palette.grey[700],
                  }}
                  onClick={() => router.navigate("/login")}
                >
                  Login
                </Button>
              </Stack>
            </Grid2>
          </Grid2>
        </Toolbar>
      </AppBar>
    </Box>
  );
}

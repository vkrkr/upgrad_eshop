import {
  Button,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Typography,
} from "@mui/material";
import { FormProvider, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useEffect, useState } from "react";
import z from "zod";

import addresses from "./addresses.json";
import FormInput from "../form-input/FormInput";
import FormInputNumber from "../form-input/FormInputNumber";
import CustomSnackbar from "../custom-snackbar/CustomSnackbar";

const formSchema = z.object({
  name: z.string().min(1),
  contactNumber: z
    .string()
    .transform((value) => Number(value))
    .refine((val) => Number.isInteger(val) && val.toString().length === 10, {
      message: "Contact number must be a valid 10-digit number",
    }),
  street: z.string().min(1),
  city: z.string().min(1),
  state: z.string().min(1),
  landmark: z.string(),
  zipCode: z.string().min(6).max(6),
});

export default function Address({ setIsAddressSelected, setAddress }) {
  const [selectedAddressId, setSelectedAddressId] = useState("");
  const [open, setOpen] = useState(false);

  const handleShowSnackbar = () => {
    setOpen(true);
  };

  const handleClose = (reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  const form = useForm({
    defaultValues: {
      name: "",
      contactNumber: "",
      street: "",
      city: "",
      state: "",
      landmark: "",
      zipCode: "",
    },
    resolver: zodResolver(formSchema),
  });

  useEffect(() => {
    setIsAddressSelected(Boolean(selectedAddressId));
    setAddress(addresses.find((address) => address.id === selectedAddressId));
  }, [selectedAddressId, setIsAddressSelected, setAddress]);

  const onSubmit = () => {
    handleShowSnackbar();
  };

  return (
    <Stack paddingX={40} paddingY={5} alignItems="center" minHeight={500}>
      <FormProvider {...form}>
        <Stack width="100%">
          <form id="address" onSubmit={form.handleSubmit(onSubmit)}>
            <Stack width="100%" spacing={3}>
              <FormControl fullWidth>
                <InputLabel id="address-label">Address</InputLabel>
                <Select
                  labelId="address-label"
                  id="address-select"
                  label="Address"
                  value={selectedAddressId}
                  onChange={(event) => {
                    setSelectedAddressId(event.target.value);
                  }}
                >
                  {addresses.map((address) => (
                    <MenuItem value={address.id} key={address.id}>
                      {address.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <Typography variant="body1" textAlign="center">
                -OR-
              </Typography>

              <Stack width="100%" spacing={3}>
                <Typography variant="h5" textAlign="center">
                  Add Address
                </Typography>

                <FormInput form={form} name="name" label="Name *" />
                <FormInputNumber
                  form={form}
                  name="contactNumber"
                  label="Contact Number *"
                />
                <FormInput form={form} name="street" label="Street *" />
                <FormInput form={form} name="city" label="City *" />
                <FormInput form={form} name="state" label="State *" />
                <FormInput form={form} name="landmark" label="Landmark" />
                <FormInput form={form} name="zipCode" label="Zip Code *" />
              </Stack>

              <Button variant="contained" type="submit" form="address">
                Save Address
              </Button>
            </Stack>
          </form>
        </Stack>
      </FormProvider>

      <CustomSnackbar
        open={open}
        handleClose={handleClose}
        message="Address Saved Successfully."
        severity="success"
      />
    </Stack>
  );
}

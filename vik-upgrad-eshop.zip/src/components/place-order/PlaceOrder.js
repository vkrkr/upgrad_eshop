import {
  Box,
  Button,
  Step,
  StepLabel,
  Stepper,
  // Typography,
} from "@mui/material";
import { Fragment, useEffect, useState } from "react";

import Address from "../address/Address";
import CustomSnackbar from "../custom-snackbar/CustomSnackbar";
import FinalizeOrder from "../finalize-order/FinalizeOrder";
import { router } from "../../App";
import { useSnackbarContext } from "../../context/snackbarContext";

const steps = ["Items", "Select Address", "Confirm Order"];

export default function PlaceOrder() {
  const [activeStep, setActiveStep] = useState(1);
  const [isAddressSelected, setIsAddressSelected] = useState();
  const [address, setAddress] = useState();

  const { open, setOpen } = useSnackbarContext();

  const handleShowSnackbar = () => {
    setOpen(true);
  };

  const handleClose = (reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  const handleNext = () => {
    if (isAddressSelected) {
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
    } else handleShowSnackbar();
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const placeOrder = () => {
    handleShowSnackbar();
    router.navigate("/");
  };

  useEffect(() => {
    if (activeStep === steps.length) {
      router.navigate("/");
    }
  }, [activeStep]);

  return (
    <Box sx={{ width: "100%" }}>
      <Stepper activeStep={activeStep}>
        {steps.map((label) => {
          const stepProps = {};
          const labelProps = {};

          return (
            <Step key={label} {...stepProps}>
              <StepLabel {...labelProps}>{label}</StepLabel>
            </Step>
          );
        })}
      </Stepper>

      {activeStep === steps.length ? (
        <Fragment>
          <CustomSnackbar
            open={open}
            handleClose={handleClose}
            message="Order Placed Successfully."
            severity="success"
          />
        </Fragment>
      ) : (
        <Fragment>
          {/* <Typography sx={{ mt: 2, mb: 1 }}>Step {activeStep + 1}</Typography> */}
          {activeStep === 1 ? (
            <Address
              setIsAddressSelected={setIsAddressSelected}
              setAddress={setAddress}
            />
          ) : (
            <FinalizeOrder address={address} />
          )}
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              pt: 2,
              justifyContent: "center",
            }}
          >
            <Button
              color="inherit"
              disabled={activeStep <= 1}
              onClick={handleBack}
              sx={{ mr: 1 }}
            >
              Back
            </Button>
            <Button
              onClick={
                activeStep === steps.length - 1 ? placeOrder : handleNext
              }
              variant="contained"
            >
              {activeStep === steps.length - 1 ? "Place Order" : "Next"}
            </Button>
          </Box>
        </Fragment>
      )}

      {!isAddressSelected && (
        <CustomSnackbar
          open={open}
          handleClose={handleClose}
          message="Please Select an Address."
          severity="error"
        />
      )}
    </Box>
  );
}

import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  Grid2,
  Stack,
  Typography,
  useTheme,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { useState } from "react";

import { router } from "../../App";
import useLocalStorage from "../../hooks/useLocalStorage";
import DeleteDialog from "../delete-dialog/DeleteDialog";

export default function ProductCard({
  id,
  name,
  price,
  description,
  imageUrl,
}) {
  const theme = useTheme();

  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { getToken, getRole } = useLocalStorage();
  const isAuthorized = Boolean(getToken()) && getRole.includes("ADMIN");

  return (
    <Card
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
      }}
    >
      <CardContent>
        <Stack spacing={1}>
          <Box
            sx={{
              maxWidth: "100%",
              height: 200,
              bgcolor: "grey",
              background: `url(${imageUrl})`,
              backgroundSize: "cover",
            }}
          />
          <Grid2 container>
            <Grid2 size={6}>
              <Typography variant="h6">{name}</Typography>
            </Grid2>
            <Grid2 size={6}>
              <Typography variant="h6" textAlign="end">
                &#8377; {price}
              </Typography>
            </Grid2>
          </Grid2>
          <Stack overflow="auto" maxHeight={80}>
            <Typography
              variant="subtitle1"
              sx={{ color: theme.palette.grey[600], flexShrink: 0 }}
            >
              {description}
            </Typography>
          </Stack>
        </Stack>
      </CardContent>
      <CardActions sx={{ padding: 2 }}>
        <Grid2 container width="100%">
          <Grid2 size={6}>
            <Button
              variant="contained"
              onClick={() => router.navigate(`/product-details/${id}`)}
            >
              Buy
            </Button>
          </Grid2>
          {isAuthorized && (
            <Grid2 size={6}>
              <Stack direction="row" justifyContent="flex-end">
                <Button
                  variant="text"
                  sx={{ color: theme.palette.grey[600] }}
                  onClick={() => router.navigate(`/modify-product/${id}`)}
                >
                  <EditIcon />
                </Button>
                <Button
                  variant="text"
                  sx={{ color: theme.palette.grey[600] }}
                  onClick={() => setIsDialogOpen(true)}
                >
                  <DeleteIcon />
                </Button>
              </Stack>
            </Grid2>
          )}
        </Grid2>
      </CardActions>

      <DeleteDialog
        open={isDialogOpen}
        onClose={() => setIsDialogOpen(false)}
        productId={id}
      />
    </Card>
  );
}

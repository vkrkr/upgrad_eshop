import { Skeleton, ToggleButton, ToggleButtonGroup } from "@mui/material";

import categoriesJson from "./categories.json";
import { apiUrl } from "../../common/apiRequirements";
import useGet from "../../hooks/useGet";
import Error from "../error/Error";

export default function ProductFilters({ category, setCategory }) {
  const { error, data } = useGet(apiUrl("/api/products/categories"));

  const handleChange = (event, newCategory) => {
    setCategory(newCategory);
  };

  if (!data && !error) {
    return <Skeleton variant="rectangular" width="100%" height={300} />;
  }

  if (!data && error) {
    return <Error />;
  }

  const categories = data?.data ?? ["all", ...categoriesJson];

  return (
    <ToggleButtonGroup
      color="primary"
      value={category}
      exclusive
      onChange={handleChange}
      aria-label="Platform"
    >
      {categories.map((category) => (
        <ToggleButton key={category} value={category}>
          {category}
        </ToggleButton>
      ))}
    </ToggleButtonGroup>
  );
}

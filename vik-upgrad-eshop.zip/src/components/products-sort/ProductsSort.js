import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Stack,
} from "@mui/material";

export const sortBy = [
  "Default",
  "Price: High to Low",
  "Price: Low to High",
  "Newest",
];

export default function ProductsSort({
  selectedSort,
  setSelectedSort,
  productsList,
  setProducts,
}) {
  const handleSort = (value) => {
    if (value === "Price: High to Low") {
      setProducts([...productsList].sort((a, b) => b.price - a.price));
    } else if (value === "Price: Low to High") {
      setProducts([...productsList].sort((a, b) => a.price - b.price));
    } else {
      setProducts([...productsList]);
    }
  };

  return (
    <Stack width={300}>
      <FormControl fullWidth>
        <InputLabel id="sortby-label">Sort By:</InputLabel>
        <Select
          labelId="sortby-label"
          id="sortby-select"
          label="Sort By:"
          value={selectedSort}
          onChange={(event) => {
            setSelectedSort(event.target.value);
            handleSort(event.target.value);
          }}
        >
          {sortBy.map((sortby) => (
            <MenuItem value={sortby} key={sortby}>
              {sortby}
            </MenuItem>
          ))}
        </Select>
      </FormControl>
    </Stack>
  );
}

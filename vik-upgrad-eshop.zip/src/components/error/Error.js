import { Stack, Typography } from "@mui/material";
import ErrorIcon from "@mui/icons-material/Error";

export default function Error() {
  return (
    <Stack
      width="100%"
      padding={2}
      color="red"
      border={1}
      direction="row"
      alignItems="center"
      spacing={1}
      bgcolor="#ff000022"
    >
      <ErrorIcon />
      <Typography variant="outlined" textAlign="center">
        An unexpected error has occured!
      </Typography>
    </Stack>
  );
}

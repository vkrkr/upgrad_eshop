import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Stack,
  Typography,
} from "@mui/material";
import { useState } from "react";

import useDelete from "../../hooks/useDelete";
import useLocalStorage from "../../hooks/useLocalStorage";
import CustomSnackbar from "../custom-snackbar/CustomSnackbar";
import { apiUrl } from "../../common/apiRequirements";

export default function DeleteDialog({
  open: dialogOpen,
  onClose: dialogClose,
  productId,
}) {
  const [success, setSuccess] = useState();
  const [open, setOpen] = useState(false);

  const { getToken, getRole } = useLocalStorage();
  const isAuthorized = Boolean(getToken()) && getRole.includes("ADMIN");

  const { deleteApi } = useDelete();

  const handleDelete = async () => {
    try {
      const response = await deleteApi(apiUrl(`/api/products/${productId}`));
      if (response.status === 200) {
        setSuccess(true);
      }
    } catch (error) {
      setSuccess(false);
    }

    setOpen(true);
    dialogClose();
  };

  if (!isAuthorized) {
    return null;
  }

  return (
    <>
      <Dialog open={dialogOpen} onClose={dialogClose} fullWidth maxWidth="sm">
        <DialogTitle>
          <Typography variant="h5" fontWeight={600}>
            Confirm Deletion of Product
          </Typography>
        </DialogTitle>
        <DialogContent>
          <Typography variant="h6" color="red">
            Are you sure you want to delete the product?
          </Typography>
        </DialogContent>
        <DialogActions>
          <Stack spacing={1} direction="row">
            <Button variant="contained" onClick={() => handleDelete()}>
              Ok
            </Button>
            <Button onClick={() => dialogClose()}>Cancel</Button>
          </Stack>
        </DialogActions>
      </Dialog>

      <CustomSnackbar
        open={open}
        handleClose={() => setOpen(false)}
        message={
          success ? "Product Deleted Successfully." : "Product Deletion Failed."
        }
        severity={success ? "success" : "error"}
      />
    </>
  );
}

import { zodResolver } from "@hookform/resolvers/zod";
import {
  Button,
  Card,
  CardActions,
  CardContent,
  Stack,
  Typography,
} from "@mui/material";
import { FormProvider, useForm } from "react-hook-form";
import { useState } from "react";
import z from "zod";

import { router } from "../../App";
import usePost from "../../hooks/usePost";
import FormInput from "../form-input/FormInput";
import useLocalStorage from "../../hooks/useLocalStorage";
import CustomSnackbar from "../custom-snackbar/CustomSnackbar";
import { useSnackbarContext } from "../../context/snackbarContext";
import { apiUrl } from "../../common/apiRequirements";

export const formSchema = z.object({
  email: z
    .string()
    .min(1, { message: "Email is required" })
    .email({ message: "Invalid email address" }),
  password: z
    .string()
    .min(4, { message: "Password must contain minimum 4 characters" }),
});

export default function Login() {
  const form = useForm({
    defaultValues: {
      email: "",
      password: "",
    },
    resolver: zodResolver(formSchema),
  });

  const [success, setSuccess] = useState(false);

  const { setLocalData } = useLocalStorage();
  const { open, setOpen, handleClose } = useSnackbarContext();

  const { postApi } = usePost();

  const onSubmit = async (data) => {
    try {
      const response = await postApi(apiUrl("/api/auth/signin"), data);
      if (response.status === 200) {
        setSuccess(true);
        setLocalData("xAuthToken", response.headers["x-auth-token"]);
        setLocalData("userRole", response.data.roles);
        router.navigate("/");
      }
    } catch (error) {
      setSuccess(false);
    }
    setOpen(true);
  };

  return (
    <Stack padding={20}>
      <Stack width="100%" maxWidth={600} alignSelf="center">
        <Card>
          <CardContent>
            <Stack spacing={2}>
              <Typography variant="h5" textAlign="center">
                Login
              </Typography>
              <FormProvider>
                <form id="login" onSubmit={form.handleSubmit(onSubmit)}>
                  <Stack spacing={2}>
                    <FormInput form={form} name="email" label="Email *" />
                    <FormInput form={form} name="password" label="Password *" />
                  </Stack>
                </form>
              </FormProvider>
            </Stack>
          </CardContent>

          <CardActions sx={{ padding: 2 }}>
            <Stack spacing={2} width="100%">
              <Button type="submit" form="login" variant="contained" fullWidth>
                Login
              </Button>

              <Button
                type="button"
                variant="text"
                fullWidth
                sx={{
                  textTransform: "none",
                  textAlign: "start",
                  textDecoration: "underline",
                }}
                onClick={() => router.navigate("/signup")}
              >
                Don't have an account? Signup
              </Button>
            </Stack>
          </CardActions>
        </Card>
      </Stack>

      {success ? (
        <CustomSnackbar
          open={open}
          handleClose={handleClose}
          message="Login Success."
          severity="success"
        />
      ) : (
        <CustomSnackbar
          open={open}
          handleClose={handleClose}
          message="Login Failed."
          severity="error"
        />
      )}
    </Stack>
  );
}

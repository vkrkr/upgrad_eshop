import { FormProvider, useForm } from "react-hook-form";
import {
  Button,
  Card,
  CardActions,
  CardContent,
  Stack,
  Typography,
} from "@mui/material";
import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import axios from "axios";
import z from "zod";

import { router } from "../../App";
import FormInput from "../form-input/FormInput";
import FormInputNumber from "../form-input/FormInputNumber";
import CustomSnackbar from "../custom-snackbar/CustomSnackbar";
import { apiUrl } from "../../common/apiRequirements";

const formSchema = z
  .object({
    email: z
      .string()
      .min(1, { message: "Email is required" })
      .email({ message: "Invalid email address" }),
    password: z
      .string()
      .min(4, { message: "Password must contain at least 4 characters" }),
    confirmPassword: z
      .string()
      .min(4, { message: "Password must contain at least 4 characters" }),
    firstName: z.string().min(1),
    lastName: z.string().min(1),
    contactNumber: z
      .string()
      .transform((value) => (value.trim() === "" ? undefined : Number(value))) // Handle empty strings and convert to number
      .optional()
      .refine(
        (val) =>
          val === undefined ||
          (Number.isInteger(val) && val.toString().length === 10),
        { message: "Contact number must be a valid 10-digit number" }
      ),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export default function Signup() {
  const [open, setOpen] = useState(false);
  const [success, setSuccess] = useState(false);

  const form = useForm({
    defaultValues: {
      email: "",
      password: "",
      firstName: "",
      lastName: "",
      contactNumber: "",
      role: ["admin"],
    },
    resolver: zodResolver(formSchema),
  });

  const onSubmit = async (data) => {
    try {
      const response = await axios.post(apiUrl("/api/auth/signup"), data);
      if (response.status === 200) {
        setSuccess(true);
      }
    } catch (error) {
      console.log(error);
      setSuccess(false);
    }
    setOpen(true);
  };

  return (
    <Stack width="100%" maxWidth={600} alignSelf="center">
      <Card>
        <CardContent>
          <Stack spacing={2}>
            <Typography variant="h5" textAlign="center">
              Create New Account
            </Typography>
            <FormProvider>
              <form id="signup" onSubmit={form.handleSubmit(onSubmit)}>
                <Stack spacing={2}>
                  <FormInput form={form} name="email" label="Email *" />
                  <FormInput
                    form={form}
                    name="firstName"
                    label="First Name *"
                  />
                  <FormInput form={form} name="lastName" label="Last Name *" />
                  <FormInput form={form} name="password" label="Password *" />
                  <FormInput
                    form={form}
                    name="confirmPassword"
                    label="Confirm Password *"
                  />
                  <FormInputNumber
                    form={form}
                    name="contactNumber"
                    label="Contact Number"
                  />
                </Stack>
              </form>
            </FormProvider>
          </Stack>
        </CardContent>

        <CardActions sx={{ padding: 2 }}>
          <Stack spacing={2} width="100%">
            <Button type="submit" form="signup" variant="contained" fullWidth>
              Sign up
            </Button>
            <Button
              type="button"
              variant="text"
              fullWidth
              sx={{
                textTransform: "none",
                textAlign: "start",
                textDecoration: "underline",
              }}
              onClick={() => router.navigate("/login")}
            >
              Already have an account? Login
            </Button>
          </Stack>
        </CardActions>
      </Card>

      <CustomSnackbar
        open={open}
        handleClose={() => setOpen(false)}
        message={
          success ? "Account Created Successfully." : "Account Creation Failed."
        }
        severity={success ? "success" : "error"}
      />
    </Stack>
  );
}

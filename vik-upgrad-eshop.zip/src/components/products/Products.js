import { Grid2, Skeleton, Stack } from "@mui/material";
import { useEffect, useMemo, useState } from "react";

import useGet from "../../hooks/useGet";
import productsJson from "../products/products.json";
import ProductCard from "../product-card/ProductCard";
import CustomSnackbar from "../custom-snackbar/CustomSnackbar";
import ProductFilters from "../products-filters/ProductsFilters";
import { useSnackbarContext } from "../../context/snackbarContext";
import ProductsSort from "../products-sort/ProductsSort";
import { apiUrl } from "../../common/apiRequirements";
import Error from "../error/Error";

export default function Products() {
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState("all");
  const [selectedSort, setSelectedSort] = useState("Default");

  const { open, setOpen } = useSnackbarContext();

  const { loading, error, data } = useGet(apiUrl("/api/products"));

  const handleClose = (reason) => {
    if (reason === "clickaway") {
      return;
    }

    setOpen(false);
  };

  const productsList = useMemo(() => {
    const allProducts = data?.data ?? productsJson;
    if (category !== "all") {
      return allProducts.filter(
        (product) =>
          String(product.category)
            .toLowerCase()
            .includes(String(category).toLowerCase()) ||
          String(category)
            .toLowerCase()
            .includes(String(product.category).toLowerCase())
      );
    }
    return allProducts;
  }, [data?.data, category]);

  useEffect(() => {
    setProducts(productsList);
  }, [productsList]);

  if (!data && loading) {
    return <Skeleton variant="rectangular" width="100%" height={300} />;
  }

  if (!data && error) {
    return <Error />;
  }

  return (
    <Stack spacing={2}>
      <Stack width="100%" direction="row" justifyContent="center">
        <ProductFilters category={category} setCategory={setCategory} />
      </Stack>
      <ProductsSort
        selectedSort={selectedSort}
        setSelectedSort={setSelectedSort}
        productsList={productsList}
        setProducts={setProducts}
      />
      <Grid2 container spacing={2}>
        {products.map((item) => (
          <Grid2 key={item.id} size={4}>
            <ProductCard {...item} />
          </Grid2>
        ))}
      </Grid2>
      <CustomSnackbar
        open={open}
        handleClose={handleClose}
        message="Order Placed Successfully."
        severity="success"
      />
    </Stack>
  );
}
